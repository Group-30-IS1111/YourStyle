﻿Public Class frmRegister
    Private Sub frmRegister_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LoginDataSet1.Login' table. You can move, or remove it, as needed.
        Me.LoginTableAdapter.Fill(Me.LoginDataSet1.Login)
        BindingSource1.AddNew()
        txtUsername.Focus()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtName.Clear()
        txtEmail.Clear()
        txtUsername.Clear()
        txtPassword.Clear()
        txtConfirm.Clear()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Me.Hide()
        txtName.Clear()
        txtEmail.Clear()
        txtUsername.Clear()
        txtPassword.Clear()
        txtConfirm.Clear()
        frmCustomerLogin.Show()
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click

        If txtName.Text = "" Then
            MessageBox.Show("Please enter your Name", "Error")
            txtName.Focus()
        ElseIf txtEmail.Text = "" Then
            MessageBox.Show("Please enter your E-mail Address", "Error")
            txtEmail.Focus()
        ElseIf txtUsername.Text = "" Then
            MessageBox.Show("Please enter your Username", "Error")
            txtUsername.Focus()
        ElseIf txtPassword.Text = "" Then
            MessageBox.Show("Please enter your Password", "Error")
            txtPassword.Focus()
        ElseIf txtConfirm.Text = "" Then
            MessageBox.Show("Please confirm your Password", "Error")
            txtConfirm.Focus()
        ElseIf txtPassword.Text <> txtConfirm.Text Then
            MessageBox.Show("The passwords do not match", "Error")
            txtConfirm.Focus()
        Else
            Dim rnum As Integer = dgvLogin.Rows.Count - 2
            dgvLogin.Rows.Item(rnum).Cells("UsernameDataGridViewTextBoxColumn").Value = txtUsername.Text
            dgvLogin.Rows.Item(rnum).Cells("EmailAddressDataGridViewTextBoxColumn").Value = txtEmail.Text
            dgvLogin.Rows.Item(rnum).Cells("NameDataGridViewTextBoxColumn").Value = txtName.Text
            dgvLogin.Rows.Item(rnum).Cells("PasswordDataGridViewTextBoxColumn").Value = txtPassword.Text

            Try
                BindingSource1.EndEdit()
                LoginTableAdapter.Update(LoginDataSet1.Login)
                MessageBox.Show("You have successfully registered. Please Login", "Registered")
                frmCustomerLogin.Show()
                Me.Hide()
            Catch ex As Exception
                MessageBox.Show("Registration unsuccessful", "Error")
                txtName.Clear()
                txtEmail.Clear()
                txtUsername.Clear()
                txtPassword.Clear()
                txtConfirm.Clear()
            End Try
        End If
    End Sub
End Class