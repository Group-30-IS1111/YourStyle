﻿Public Class frmRegisterEmployee
    Private Sub frmRegisterEmployee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LoginDataSet3.EmployeeLogin' table. You can move, or remove it, as needed.
        Me.EmployeeLoginTableAdapter.Fill(Me.LoginDataSet3.EmployeeLogin)
        BindingSource1.AddNew()
        txtUsername.Focus()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtName.Clear()
        txtEmail.Clear()
        txtUsername.Clear()
        txtPassword.Clear()
        txtConfirm.Clear()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Me.Hide()
        txtName.Clear()
        txtEmail.Clear()
        txtUsername.Clear()
        txtPassword.Clear()
        txtConfirm.Clear()
        frmCustomerLogin.Show()
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click

        If txtName.Text = "" Then
            MessageBox.Show("Please enter your Name", "Error")
            txtName.Focus()
        ElseIf txtEmail.Text = "" Then
            MessageBox.Show("Please enter your E-mail Address", "Error")
            txtEmail.Focus()
        ElseIf txtUsername.Text = "" Then
            MessageBox.Show("Please enter your Username", "Error")
            txtUsername.Focus()
        ElseIf txtPassword.Text = "" Then
            MessageBox.Show("Please enter your Password", "Error")
            txtPassword.Focus()
        ElseIf txtConfirm.Text = "" Then
            MessageBox.Show("Please confirm your Password", "Error")
            txtConfirm.Focus()
        ElseIf txtPassword.Text <> txtConfirm.Text Then
            MessageBox.Show("The passwords do not match", "Error")
            txtConfirm.Focus()
        Else
            Dim rnum As Integer = dgvEmployee.Rows.Count - 2
            dgvEmployee.Rows.Item(rnum).Cells("UsernameDataGridViewTextBoxColumn").Value = txtUsername.Text
            dgvEmployee.Rows.Item(rnum).Cells("EmailAddressDataGridViewTextBoxColumn").Value = txtEmail.Text
            dgvEmployee.Rows.Item(rnum).Cells("NameDataGridViewTextBoxColumn").Value = txtName.Text
            dgvEmployee.Rows.Item(rnum).Cells("PasswordDataGridViewTextBoxColumn").Value = txtPassword.Text

            Try
                BindingSource1.EndEdit()
                EmployeeLoginTableAdapter.Update(LoginDataSet3.EmployeeLogin)
                MessageBox.Show("You have successfully registered. Please Login", "Registered")
                frmCustomerLogin.Show()
                Me.Hide()
            Catch ex As Exception
                MessageBox.Show("Registration unsuccessful", "Error")
                txtName.Clear()
                txtEmail.Clear()
                txtUsername.Clear()
                txtPassword.Clear()
                txtConfirm.Clear()
            End Try
        End If
    End Sub
End Class