﻿'We worked well as a group and delegated all the work

'Ailíse Ryan 119396633 - Ailíse did the customer side of things; if you log in as a customer etc
'She also got everyones indiviudal work and put it together and briefly desgined it to make this program

'Paul Drinan 119451216 - Paul worked on the manager/owner side of the program; if you log in as the owner manager that is his work
'He also worked on the user manual

'Diarmuid Hurley 119376016 - Diarmuid worked on the login and the register for this program and at the end made sure the program
'worked for definate

'Michael Hammett 119472154 - Michael worked on the employee side of things; what you would see if the employee log into this program 
'and how they can work

Public Class frmStartUp
    Private Sub btnProceed_Click(sender As Object, e As EventArgs) Handles btnProceed.Click
        If rdoCustomer.Checked Then
            frmCustomerLogin.Show()
        ElseIf rdoEmployee.Checked Then
            frmEmployeeLogin.Show()
        ElseIf rdoManager.Checked Then
            frmManagerLogin.Show()
        End If
        Me.Hide()
    End Sub
End Class