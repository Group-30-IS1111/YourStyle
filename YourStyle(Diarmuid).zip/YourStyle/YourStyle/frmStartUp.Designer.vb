﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStartUp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblChoose = New System.Windows.Forms.Label()
        Me.rdoCustomer = New System.Windows.Forms.RadioButton()
        Me.rdoEmployee = New System.Windows.Forms.RadioButton()
        Me.rdoManager = New System.Windows.Forms.RadioButton()
        Me.btnProceed = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblChoose
        '
        Me.lblChoose.AutoSize = True
        Me.lblChoose.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!)
        Me.lblChoose.Location = New System.Drawing.Point(121, 9)
        Me.lblChoose.Name = "lblChoose"
        Me.lblChoose.Size = New System.Drawing.Size(188, 46)
        Me.lblChoose.TabIndex = 0
        Me.lblChoose.Text = "I am a(n):"
        '
        'rdoCustomer
        '
        Me.rdoCustomer.AutoSize = True
        Me.rdoCustomer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.rdoCustomer.Location = New System.Drawing.Point(16, 113)
        Me.rdoCustomer.Name = "rdoCustomer"
        Me.rdoCustomer.Size = New System.Drawing.Size(118, 29)
        Me.rdoCustomer.TabIndex = 1
        Me.rdoCustomer.TabStop = True
        Me.rdoCustomer.Text = "Customer"
        Me.rdoCustomer.UseVisualStyleBackColor = True
        '
        'rdoEmployee
        '
        Me.rdoEmployee.AutoSize = True
        Me.rdoEmployee.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.rdoEmployee.Location = New System.Drawing.Point(155, 113)
        Me.rdoEmployee.Name = "rdoEmployee"
        Me.rdoEmployee.Size = New System.Drawing.Size(120, 29)
        Me.rdoEmployee.TabIndex = 2
        Me.rdoEmployee.TabStop = True
        Me.rdoEmployee.Text = "Employee"
        Me.rdoEmployee.UseVisualStyleBackColor = True
        '
        'rdoManager
        '
        Me.rdoManager.AutoSize = True
        Me.rdoManager.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.rdoManager.Location = New System.Drawing.Point(296, 113)
        Me.rdoManager.Name = "rdoManager"
        Me.rdoManager.Size = New System.Drawing.Size(111, 29)
        Me.rdoManager.TabIndex = 3
        Me.rdoManager.TabStop = True
        Me.rdoManager.Text = "Manager"
        Me.rdoManager.UseVisualStyleBackColor = True
        '
        'btnProceed
        '
        Me.btnProceed.Location = New System.Drawing.Point(125, 204)
        Me.btnProceed.Name = "btnProceed"
        Me.btnProceed.Size = New System.Drawing.Size(180, 42)
        Me.btnProceed.TabIndex = 4
        Me.btnProceed.Text = "Proceed"
        Me.btnProceed.UseVisualStyleBackColor = True
        '
        'frmStartUp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(435, 283)
        Me.Controls.Add(Me.btnProceed)
        Me.Controls.Add(Me.rdoManager)
        Me.Controls.Add(Me.rdoEmployee)
        Me.Controls.Add(Me.rdoCustomer)
        Me.Controls.Add(Me.lblChoose)
        Me.Name = "frmStartUp"
        Me.Text = "Start Up "
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblChoose As Label
    Friend WithEvents rdoCustomer As RadioButton
    Friend WithEvents rdoEmployee As RadioButton
    Friend WithEvents rdoManager As RadioButton
    Friend WithEvents btnProceed As Button
End Class
