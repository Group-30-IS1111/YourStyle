﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMenu))
        Me.btnMenu = New System.Windows.Forms.Button()
        Me.btnReports = New System.Windows.Forms.Button()
        Me.btnQuery = New System.Windows.Forms.Button()
        Me.btnStaff = New System.Windows.Forms.Button()
        Me.btnOrders = New System.Windows.Forms.Button()
        Me.picYourStyle = New System.Windows.Forms.PictureBox()
        Me.lblYourStyle = New System.Windows.Forms.Label()
        Me.frmLogOut = New System.Windows.Forms.Button()
        CType(Me.picYourStyle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnMenu
        '
        Me.btnMenu.Location = New System.Drawing.Point(3, 26)
        Me.btnMenu.Name = "btnMenu"
        Me.btnMenu.Size = New System.Drawing.Size(250, 39)
        Me.btnMenu.TabIndex = 2
        Me.btnMenu.Text = "Menu"
        Me.btnMenu.UseVisualStyleBackColor = True
        '
        'btnReports
        '
        Me.btnReports.Location = New System.Drawing.Point(250, 26)
        Me.btnReports.Name = "btnReports"
        Me.btnReports.Size = New System.Drawing.Size(250, 39)
        Me.btnReports.TabIndex = 3
        Me.btnReports.Text = "Reports"
        Me.btnReports.UseVisualStyleBackColor = True
        '
        'btnQuery
        '
        Me.btnQuery.Location = New System.Drawing.Point(497, 26)
        Me.btnQuery.Name = "btnQuery"
        Me.btnQuery.Size = New System.Drawing.Size(250, 39)
        Me.btnQuery.TabIndex = 4
        Me.btnQuery.Text = "Query"
        Me.btnQuery.UseVisualStyleBackColor = True
        '
        'btnStaff
        '
        Me.btnStaff.Location = New System.Drawing.Point(744, 26)
        Me.btnStaff.Name = "btnStaff"
        Me.btnStaff.Size = New System.Drawing.Size(250, 39)
        Me.btnStaff.TabIndex = 5
        Me.btnStaff.Text = "Staff"
        Me.btnStaff.UseVisualStyleBackColor = True
        '
        'btnOrders
        '
        Me.btnOrders.Location = New System.Drawing.Point(990, 26)
        Me.btnOrders.Name = "btnOrders"
        Me.btnOrders.Size = New System.Drawing.Size(250, 39)
        Me.btnOrders.TabIndex = 6
        Me.btnOrders.Text = "Orders"
        Me.btnOrders.UseVisualStyleBackColor = True
        '
        'picYourStyle
        '
        Me.picYourStyle.Image = CType(resources.GetObject("picYourStyle.Image"), System.Drawing.Image)
        Me.picYourStyle.Location = New System.Drawing.Point(356, 224)
        Me.picYourStyle.Name = "picYourStyle"
        Me.picYourStyle.Size = New System.Drawing.Size(545, 330)
        Me.picYourStyle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picYourStyle.TabIndex = 7
        Me.picYourStyle.TabStop = False
        '
        'lblYourStyle
        '
        Me.lblYourStyle.AutoSize = True
        Me.lblYourStyle.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYourStyle.Location = New System.Drawing.Point(64, 132)
        Me.lblYourStyle.Name = "lblYourStyle"
        Me.lblYourStyle.Size = New System.Drawing.Size(665, 46)
        Me.lblYourStyle.TabIndex = 8
        Me.lblYourStyle.Text = "Your Style - Manager/Owner Access"
        '
        'frmLogOut
        '
        Me.frmLogOut.Location = New System.Drawing.Point(1026, 564)
        Me.frmLogOut.Name = "frmLogOut"
        Me.frmLogOut.Size = New System.Drawing.Size(126, 41)
        Me.frmLogOut.TabIndex = 9
        Me.frmLogOut.Text = "Log Out"
        Me.frmLogOut.UseVisualStyleBackColor = True
        '
        'frmMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.ClientSize = New System.Drawing.Size(1244, 631)
        Me.Controls.Add(Me.frmLogOut)
        Me.Controls.Add(Me.lblYourStyle)
        Me.Controls.Add(Me.picYourStyle)
        Me.Controls.Add(Me.btnOrders)
        Me.Controls.Add(Me.btnStaff)
        Me.Controls.Add(Me.btnQuery)
        Me.Controls.Add(Me.btnReports)
        Me.Controls.Add(Me.btnMenu)
        Me.Name = "frmMenu"
        Me.Text = "Menu"
        CType(Me.picYourStyle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnMenu As Button
    Friend WithEvents btnReports As Button
    Friend WithEvents btnQuery As Button
    Friend WithEvents btnStaff As Button
    Friend WithEvents btnOrders As Button
    Friend WithEvents picYourStyle As PictureBox
    Friend WithEvents lblYourStyle As Label
    Friend WithEvents frmLogOut As Button
End Class
