﻿Public Class frmMenu
    Private Sub btnReports_Click(sender As Object, e As EventArgs) Handles btnReports.Click
        Me.Hide()
        frmReport.Show()
    End Sub

    Private Sub btnQuery_Click(sender As Object, e As EventArgs) Handles btnQuery.Click
        Me.Hide()
        frmQuery.Show()
    End Sub

    Private Sub btnStaff_Click(sender As Object, e As EventArgs) Handles btnStaff.Click
        Me.Hide()
        frmStaff.Show()
    End Sub

    Private Sub btnOrders_Click(sender As Object, e As EventArgs) Handles btnOrders.Click
        Me.Hide()
        frmOrders.Show()
    End Sub

    Private Sub frmLogOut_Click(sender As Object, e As EventArgs) Handles frmLogOut.Click
        Me.Hide()
        frmLogin.Show()
    End Sub
End Class