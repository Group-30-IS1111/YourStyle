﻿Public Class frmDesign
    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        'When button is clicked current form will hide and Payment form will show
        frmPayment.Show()
        Me.Hide()

        'Whatever radio button is selected, that show style will appear in Model text box in the Payment form
        If rdbClassic.Checked Then
            frmPayment.txtModel.Text = "Classic"
            Dim strClassic As String = 54.49
            frmPayment.txtModel2.Text = FormatCurrency(strClassic)
        ElseIf rdbRetro.Checked Then
            frmPayment.txtModel.Text = "Retro"
            Dim strRetro As String = 49.5
            frmPayment.txtModel2.Text = FormatCurrency(strRetro)
        ElseIf rdbVintage.Checked Then
            frmPayment.txtModel.Text = "Vintage"
            Dim strVintage As String = 44.99
            frmPayment.txtModel2.Text = FormatCurrency(strVintage)
        End If

        Select Case True
        'Calculations for Laces will be visable in the payment form
            Case cboLaces.Text = "White*"
                Dim strLaces As String = 0.0
                frmPayment.txtLaces2.Text = FormatCurrency(strLaces)
                frmPayment.txtLaces.Text = "White"
            Case cboLaces.Text = "Black"
                Dim strLaces As String = 4.0
                frmPayment.txtLaces2.Text = FormatCurrency(strLaces)
                frmPayment.txtLaces.Text = "Black"
            Case cboLaces.Text = "Red"
                Dim strLaces As String = 4.0
                frmPayment.txtLaces2.Text = FormatCurrency(strLaces)
                frmPayment.txtLaces.Text = "Red"
            Case cboLaces.Text = "Orange"
                Dim strLaces As String = 4.0
                frmPayment.txtLaces2.Text = FormatCurrency(strLaces)
                frmPayment.txtLaces.Text = "Orange"
            Case cboLaces.Text = "Yellow"
                Dim strLaces As String = 4.0
                frmPayment.txtLaces2.Text = FormatCurrency(strLaces)
                frmPayment.txtLaces.Text = "Yellow"
            Case cboLaces.Text = "Green"
                Dim strLaces As String = 4.0
                frmPayment.txtLaces2.Text = FormatCurrency(strLaces)
                frmPayment.txtLaces.Text = "Green"
            Case cboLaces.Text = "Blue"
                Dim strLaces As String = 4.0
                frmPayment.txtLaces2.Text = FormatCurrency(strLaces)
                frmPayment.txtLaces.Text = "Blue"
        End Select

        Select Case True
        'Calculations for Eyestay will be visable in payment form
            Case cboEyestay.Text = "White*"
                Dim strEyestay As String = 0.0
                frmPayment.txtEyestay.Text = "White"
                frmPayment.txtEyestay2.Text = FormatCurrency(strEyestay)
            Case cboEyestay.Text = "Black"
                Dim strEyestay As String = 5.0
                frmPayment.txtEyestay2.Text = FormatCurrency(strEyestay)
                frmPayment.txtEyestay.Text = "Black"
            Case cboEyestay.Text = "Red"
                Dim strEyestay As String = 5.0
                frmPayment.txtEyestay2.Text = FormatCurrency(strEyestay)
                frmPayment.txtEyestay.Text = "Red"
            Case cboEyestay.Text = "Orange"
                Dim strEyestay As String = 5.0
                frmPayment.txtEyestay2.Text = FormatCurrency(strEyestay)
                frmPayment.txtEyestay.Text = "Orange"
            Case cboEyestay.Text = "Yellow"
                Dim strEyestay As String = 5.0
                frmPayment.txtEyestay2.Text = FormatCurrency(strEyestay)
                frmPayment.txtEyestay.Text = "Yellow"
            Case cboEyestay.Text = "Green"
                Dim strEyestay As String = 5.0
                frmPayment.txtEyestay2.Text = FormatCurrency(strEyestay)
                frmPayment.txtEyestay.Text = "Green"
            Case cboEyestay.Text = "Blue"
                Dim strEyestay As String = 5.0
                frmPayment.txtEyestay2.Text = FormatCurrency(strEyestay)
                frmPayment.txtEyestay.Text = "Blue"
        End Select

        Select Case True
        'Calculations for Vamp will be visable in the payment form
            Case cboVamp.Text = "White*"
                Dim strVamp As String = 0.0
                frmPayment.txtVamp2.Text = FormatCurrency(strVamp)
                frmPayment.txtVamp.Text = "White"
            Case cboVamp.Text = "Black"
                Dim strVamp As String = 14.99
                frmPayment.txtVamp2.Text = FormatCurrency(strVamp)
                frmPayment.txtVamp.Text = "Black"
            Case cboVamp.Text = "Red"
                Dim strVamp As String = 14.99
                frmPayment.txtVamp2.Text = FormatCurrency(strVamp)
                frmPayment.txtVamp.Text = "Red"
            Case cboVamp.Text = "Orange"
                Dim strVamp As String = 14.99
                frmPayment.txtVamp2.Text = FormatCurrency(strVamp)
                frmPayment.txtVamp.Text = "Orange"
            Case cboVamp.Text = "Yellow"
                Dim strVamp As String = 14.99
                frmPayment.txtVamp2.Text = FormatCurrency(strVamp)
                frmPayment.txtVamp.Text = "Yellow"
            Case cboVamp.Text = "Green"
                Dim strVamp As String = 14.99
                frmPayment.txtVamp2.Text = FormatCurrency(strVamp)
                frmPayment.txtVamp.Text = "Green"
            Case cboVamp.Text = "Blue"
                Dim strVamp As String = 14.99
                frmPayment.txtVamp2.Text = FormatCurrency(strVamp)
                frmPayment.txtVamp.Text = "Blue"
        End Select

        Select Case True
        'Calculations for Quarter will be visable in the payment form
            Case cboQuarter.Text = "White*"
                Dim strQuarter As String = 0.0
                frmPayment.txtQuarter2.Text = FormatCurrency(strQuarter)
                frmPayment.txtQuarter.Text = "White"
            Case cboQuarter.Text = "Black"
                Dim strQuarter As String = 8.99
                frmPayment.txtQuarter2.Text = FormatCurrency(strQuarter)
                frmPayment.txtQuarter.Text = "Black"
            Case cboQuarter.Text = "Red"
                Dim strQuarter As String = 8.99
                frmPayment.txtQuarter2.Text = FormatCurrency(strQuarter)
                frmPayment.txtQuarter.Text = "Red"
            Case cboQuarter.Text = "Orange"
                Dim strQuarter As String = 8.99
                frmPayment.txtQuarter2.Text = FormatCurrency(strQuarter)
                frmPayment.txtQuarter.Text = "Orange"
            Case cboQuarter.Text = "Yellow"
                Dim strQuarter As String = 8.99
                frmPayment.txtQuarter2.Text = FormatCurrency(strQuarter)
                frmPayment.txtQuarter.Text = "Yellow"
            Case cboQuarter.Text = "Green"
                Dim strQuarter As String = 8.99
                frmPayment.txtQuarter2.Text = FormatCurrency(strQuarter)
                frmPayment.txtQuarter.Text = "Green"
            Case cboQuarter.Text = "Blue"
                Dim strQuarter As String = 8.99
                frmPayment.txtQuarter2.Text = FormatCurrency(strQuarter)
                frmPayment.txtQuarter.Text = "Blue"
        End Select

        Select Case True
        'Calculations for Back Counter will be visable in the payment form
            Case cboBackCounter.Text = "White*"
                Dim strBackCounter As String = 0.0
                frmPayment.txtBackCounter2.Text = FormatCurrency(strBackCounter)
                frmPayment.txtBackCounter.Text = "White"
            Case cboBackCounter.Text = "Black"
                Dim strBackCounter As String = 6.49
                frmPayment.txtBackCounter2.Text = FormatCurrency(strBackCounter)
                frmPayment.txtBackCounter.Text = "Black"
            Case cboBackCounter.Text = "Red"
                Dim strBackCounter As String = 6.49
                frmPayment.txtBackCounter2.Text = FormatCurrency(strBackCounter)
                frmPayment.txtBackCounter.Text = "Red"
            Case cboBackCounter.Text = "Orange"
                Dim strBackCounter As String = 6.49
                frmPayment.txtBackCounter2.Text = FormatCurrency(strBackCounter)
                frmPayment.txtBackCounter.Text = "Orange"
            Case cboBackCounter.Text = "Yellow"
                Dim strBackCounter As String = 6.49
                frmPayment.txtBackCounter2.Text = FormatCurrency(strBackCounter)
                frmPayment.txtBackCounter.Text = "Yellow"
            Case cboBackCounter.Text = "Green"
                Dim strBackCounter As String = 6.49
                frmPayment.txtBackCounter2.Text = FormatCurrency(strBackCounter)
                frmPayment.txtBackCounter.Text = "Green"
            Case cboBackCounter.Text = "Blue"
                Dim strBackCounter As String = 6.49
                frmPayment.txtBackCounter2.Text = FormatCurrency(strBackCounter)
                frmPayment.txtBackCounter.Text = "Blue"
        End Select

        Select Case True
        'Calculations for Heel Tab will be visable in the payment form
            Case cboHeelTab.Text = "White*"
                Dim strHeelTab As String = 0.0
                frmPayment.txtHeelTab2.Text = FormatCurrency(strHeelTab)
                frmPayment.txtHeelTab.Text = "White"
            Case cboHeelTab.Text = "Black"
                Dim strHeelTab As String = 4.99
                frmPayment.txtHeelTab2.Text = FormatCurrency(strHeelTab)
                frmPayment.txtHeelTab.Text = "Black"
            Case cboHeelTab.Text = "Red"
                Dim strHeelTab As String = 4.99
                frmPayment.txtHeelTab2.Text = FormatCurrency(strHeelTab)
                frmPayment.txtHeelTab.Text = "Red"
            Case cboHeelTab.Text = "Orange"
                Dim strHeelTab As String = 4.99
                frmPayment.txtHeelTab2.Text = FormatCurrency(strHeelTab)
                frmPayment.txtHeelTab.Text = "Orange"
            Case cboHeelTab.Text = "Yellow"
                Dim strHeelTab As String = 4.99
                frmPayment.txtHeelTab2.Text = FormatCurrency(strHeelTab)
                frmPayment.txtHeelTab.Text = "Yellow"
            Case cboHeelTab.Text = "Green"
                Dim strHeelTab As String = 4.99
                frmPayment.txtHeelTab2.Text = FormatCurrency(strHeelTab)
                frmPayment.txtHeelTab.Text = "Green"
            Case cboHeelTab.Text = "Blue"
                Dim strHeelTab As String = 4.99
                frmPayment.txtHeelTab2.Text = FormatCurrency(strHeelTab)
                frmPayment.txtHeelTab.Text = "Blue"
        End Select

        'Radio button for Logo if checked then result will appear in the text box in payment form
        If rdbYes.Checked Then
            frmPayment.txtLogo.Text = "Yes"
        ElseIf rdbNo.Checked Then
            frmPayment.txtLogo.Text = "No"
            Dim strLogo As String = 0.00
            frmPayment.txtLogo3.Text = FormatCurrency(strLogo)
        End If


        'Whichever shoe size is, if male, chosen this will appear in size text box in payment form
        Select Case True
            Case cboMale.Text = "EU 38"
                frmPayment.txtSize.Text = "EU 38"
            Case cboMale.Text = "EU 39"
                frmPayment.txtSize.Text = "EU 39"
            Case cboMale.Text = "EU 40"
                frmPayment.txtSize.Text = "EU 40"
            Case cboMale.Text = "EU 41 "
                frmPayment.txtSize.Text = "EU 41"
            Case cboMale.Text = "EU 42"
                frmPayment.txtSize.Text = "EU 42"
            Case cboMale.Text = "EU 43"
                frmPayment.txtSize.Text = "EU 43"
            Case cboMale.Text = "EU 44"
                frmPayment.txtSize.Text = "EU 44"
            Case cboMale.Text = "EU 45"
                frmPayment.txtSize.Text = "EU 45"
            Case cboMale.Text = "EU 46"
                frmPayment.txtSize.Text = "EU 46"
            Case cboMale.Text = "EU 47"
                frmPayment.txtSize.Text = "EU 47"
            Case cboMale.Text = "EU 48"
                frmPayment.txtSize.Text = "EU 48"
            Case cboMale.Text = "EU 49"
                frmPayment.txtSize.Text = "EU 49"
        End Select

        'Whichever shoe size is, if female, chosen this will appear in size text box in payment form
        Select Case True
            Case cboFemale.Text = "EU 34"
                frmPayment.txtSize.Text = "EU 34"
            Case cboFemale.Text = "EU 35"
                frmPayment.txtSize.Text = "EU 35"
            Case cboFemale.Text = "EU 36"
                frmPayment.txtSize.Text = "EU 36"
            Case cboFemale.Text = "EU 37"
                frmPayment.txtSize.Text = "EU 37"
            Case cboFemale.Text = "EU 38"
                frmPayment.txtSize.Text = "EU 38"
            Case cboFemale.Text = "EU 39"
                frmPayment.txtSize.Text = "EU 39"
            Case cboFemale.Text = "EU 40"
                frmPayment.txtSize.Text = "EU 40"
            Case cboFemale.Text = "EU 41"
                frmPayment.txtSize.Text = "EU 41"
            Case cboFemale.Text = "EU 42"
                frmPayment.txtSize.Text = "EU 42"
            Case cboFemale.Text = "EU 43"
                frmPayment.txtSize.Text = "EU 43"
            Case cboFemale.Text = "EU 44"
                frmPayment.txtSize.Text = "EU 44"
            Case cboFemale.Text = "EU 45"
                frmPayment.txtSize.Text = "EU 45"
        End Select

    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        'If home button is clicked current form and account form will hide
        frmHome.Show()
        Me.Hide()
        frmAccount.Hide()
    End Sub

    Private Sub btnCustomize_Click(sender As Object, e As EventArgs) Handles btnCustomize.Click
        'If customize button is clicked home form and account form will hide
        frmHome.Hide()
        Me.Show()
        frmAccount.Hide()
    End Sub

    Private Sub btnAccount_Click(sender As Object, e As EventArgs) Handles btnAccount.Click
        'If account button is clicked current form and home form will hide
        frmHome.Hide()
        Me.Hide()
        frmAccount.Show()
    End Sub

    Private Sub btnContinue_Click(sender As Object, e As EventArgs) Handles btnContinue.Click
        'When continue button clicked group box size will show
        grpSize.Show()
    End Sub

    Private Sub rdbMale_CheckedChanged(sender As Object, e As EventArgs) Handles rdbMale.CheckedChanged
        'If radio button male checked combobox male will show and combobox female will hide
        cboMale.Show()
        cboFemale.Hide()
    End Sub

    Private Sub rdbFemale_CheckedChanged(sender As Object, e As EventArgs) Handles rdbFemale.CheckedChanged
        'If radio button female checked combobox female will show and combobox male will hide
        cboFemale.Show()
        cboMale.Hide()
    End Sub
End Class
