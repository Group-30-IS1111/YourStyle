﻿Public Class EmployeeLogin
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtUsername.TextChanged
        Dim strUsername As String = "Employee"
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged
        Dim strPassword As String = "Employee"
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If txtUsername.Text = "Employee1" And txtPassword.Text = "ManOne" Then
            CustomerDetails.Show()
            Me.Hide()
        ElseIf txtUsername.Text = "Employee2" And txtPassword.Text = "JoeMan" Then
            CustomerDetails.Show()
            Me.Hide()

        ElseIf txtUsername.Text = "Employee3" And txtPassword.Text = "SteveFella" Then
            CustomerDetails.Show()
            Me.Hide()

        ElseIf txtUsername.Text = "Employee4" And txtPassword.Text = "Maeve Jones" Then
            CustomerDetails.Show()
            Me.Hide()

        ElseIf txtUsername.Text = "Employee5" And txtPassword.Text = "JonnasMcGregor" Then
            CustomerDetails.Show()
            Me.Hide()



        Else txtUsername.Text = ""
            txtPassword.Text = ""
            MessageBox.Show("Try Again! Incorrect Username or Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

    End Sub

    Private Sub btnPassword_Click(sender As Object, e As EventArgs) Handles btnPassword.Click
        If txtPassword.UseSystemPasswordChar = True Then

            txtPassword.UseSystemPasswordChar = False
            btnPassword.Text = "Show Password"
        Else
            txtPassword.UseSystemPasswordChar = True
            btnPassword.Text = "Hide Password"
        End If
    End Sub
End Class