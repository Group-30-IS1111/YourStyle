﻿Public Class CustomerDetails
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'IS1111_Project_DatabaseDataSet.Customer_Details' table. You can move, or remove it, as needed.
        Me.Customer_DetailsTableAdapter.Fill(Me.IS1111_Project_DatabaseDataSet.Customer_Details)

    End Sub

    Private Sub Customer_DetailsDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'Saves new data that is entered in
        Try
            Me.Validate()
            BindingSource1.EndEdit()
            Customer_DetailsTableAdapter.Update(Me.IS1111_Project_DatabaseDataSet)
            MessageBox.Show("Data Saved", "Status Update")
        Catch ex As Exception
            MessageBox.Show("Error Saving Data")
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        BindingContext(IS1111_Project_DatabaseDataSet, "Customer_Details").Position = BindingContext(IS1111_Project_DatabaseDataSet, "Customer_Details").Position + 1
    End Sub

    Private Sub btnViewProductProgress_Click(sender As Object, e As EventArgs) Handles btnViewProductProgress.Click
        'Whatever name is appearing a different status will appear in a message box
        Timer1.Start()
        If NameTextBox.Text = "Jane Kelleher" Then
            Call Person1()
        End If
        If NameTextBox.Text = "Michael Davidson" Then
            Call Person2()
        End If
        If NameTextBox.Text = "Nathan Umbridge" Then
            Call Person3()
        End If
        If NameTextBox.Text = "Samuel Sampson" Then
            Call Person4()
        End If
        If NameTextBox.Text = "Connor O' Connor" Then
            Call Person5()
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'Loading progress bar
        ProgressBar1.Increment(20)
        If ProgressBar1.Value = 100 Then
            Timer1.Stop()

        End If
    End Sub
    Private Sub Person1()
        MessageBox.Show("Your Style are really busy at the moment and will ship your order to their facilities as soon as possible", "Still awaiting shipment")

    End Sub
    Private Sub Person2()
        MessageBox.Show("Right now, the Your Style team are working really hard on customizing the items you requested.Getting close!", "Being Customized")
    End Sub
    Private Sub Person3()
        MessageBox.Show("Your Style have shipped your order and it is in the list of goods to be customized", "Shipped and awaiting customization")
    End Sub
    Private Sub Person4()
        MessageBox.Show("Woohoo-your item(s) is/are customized, packed & on its way to the Your Style outlet. Get here as fast as the laws of physics allow. And the Guards!", "Customized and returned to outlet.")
    End Sub
    Private Sub Person5()
        MessageBox.Show("Right now, the Your Style team are working really hard on customizing the items you requested.Getting close!", "Being Customized")
    End Sub
    Private Sub Person1Updated()
        MessageBox.Show("Your Style have shipped your order and it is in the list of goods to be customized", "Shipped and awaiting customization")
    End Sub
    Private Sub Person2Updated()
        MessageBox.Show("Woohoo-your item(s) is/are customized, packed & on its way to the Your Style outlet. Get here as fast as the laws of physics allow. And the Guards!", "Customized and returned to outlet.")
    End Sub
    Private Sub Person3Updated()
        MessageBox.Show("Right now, the Your Style team are working really hard on customizing the items you requested.Getting close!", "Being Customized")
    End Sub
    Private Sub Person4Updated()
        MessageBox.Show("Your Product(s) await your collection", "Woohoo")
    End Sub
    Private Sub Person5Updated()
        MessageBox.Show("The status of your product(s) is yet to change", "Status Update")
    End Sub

    Private Sub rdoChangeStatus_CheckedChanged(sender As Object, e As EventArgs) Handles rdoChangeStatus.CheckedChanged
        If rdoChangeStatus.Checked And NameTextBox.Text = "Jane Kelleher" Then
            Call Person1Updated()
        End If
        If rdoChangeStatus.Checked And NameTextBox.Text = "Michael Davidson" Then
            Call Person2Updated()
        End If
        If rdoChangeStatus.Checked And NameTextBox.Text = "Nathan Umbridge" Then
            Call Person3Updated()
        End If
        If rdoChangeStatus.Checked And NameTextBox.Text = "Samuel Sampson" Then
            Call Person4Updated()
        End If
        If rdoChangeStatus.Checked And NameTextBox.Text = "Connor O' Connor" Then
            Call Person5Updated()
        End If
    End Sub
End Class
