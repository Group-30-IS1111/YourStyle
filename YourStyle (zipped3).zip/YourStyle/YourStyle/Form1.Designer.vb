﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDesign
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDesign))
        Me.btnHome = New System.Windows.Forms.Button()
        Me.btnCustomize = New System.Windows.Forms.Button()
        Me.btnAccount = New System.Windows.Forms.Button()
        Me.grpStyle = New System.Windows.Forms.GroupBox()
        Me.picWhiteVintage = New System.Windows.Forms.PictureBox()
        Me.picWhiteRetro = New System.Windows.Forms.PictureBox()
        Me.picWhite = New System.Windows.Forms.PictureBox()
        Me.picPink = New System.Windows.Forms.PictureBox()
        Me.rdbRetro = New System.Windows.Forms.RadioButton()
        Me.rdbClassic = New System.Windows.Forms.RadioButton()
        Me.rdbVintage = New System.Windows.Forms.RadioButton()
        Me.grpDesign = New System.Windows.Forms.GroupBox()
        Me.grpLogo = New System.Windows.Forms.GroupBox()
        Me.lblLogo = New System.Windows.Forms.Label()
        Me.btnContinue = New System.Windows.Forms.Button()
        Me.rdbYes = New System.Windows.Forms.RadioButton()
        Me.rdbNo = New System.Windows.Forms.RadioButton()
        Me.grpSize = New System.Windows.Forms.GroupBox()
        Me.cboFemale = New System.Windows.Forms.ComboBox()
        Me.cboMale = New System.Windows.Forms.ComboBox()
        Me.rdbFemale = New System.Windows.Forms.RadioButton()
        Me.rdbMale = New System.Windows.Forms.RadioButton()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.lblAdditional = New System.Windows.Forms.Label()
        Me.cboHeelTab = New System.Windows.Forms.ComboBox()
        Me.cboBackCounter = New System.Windows.Forms.ComboBox()
        Me.cboQuarter = New System.Windows.Forms.ComboBox()
        Me.cboVamp = New System.Windows.Forms.ComboBox()
        Me.cboEyestay = New System.Windows.Forms.ComboBox()
        Me.cboLaces = New System.Windows.Forms.ComboBox()
        Me.lblHeelTab = New System.Windows.Forms.Label()
        Me.lblBackCounter = New System.Windows.Forms.Label()
        Me.lblQuarter = New System.Windows.Forms.Label()
        Me.lblVamp = New System.Windows.Forms.Label()
        Me.lblEyestay = New System.Windows.Forms.Label()
        Me.lblLaces = New System.Windows.Forms.Label()
        Me.grpStyle.SuspendLayout()
        CType(Me.picWhiteVintage, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picWhiteRetro, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picWhite, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPink, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpDesign.SuspendLayout()
        Me.grpLogo.SuspendLayout()
        Me.grpSize.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(49, 25)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(383, 53)
        Me.btnHome.TabIndex = 7
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'btnCustomize
        '
        Me.btnCustomize.Location = New System.Drawing.Point(427, 25)
        Me.btnCustomize.Name = "btnCustomize"
        Me.btnCustomize.Size = New System.Drawing.Size(383, 53)
        Me.btnCustomize.TabIndex = 8
        Me.btnCustomize.Text = "Customize Your Shoe"
        Me.btnCustomize.UseVisualStyleBackColor = True
        '
        'btnAccount
        '
        Me.btnAccount.Location = New System.Drawing.Point(807, 25)
        Me.btnAccount.Name = "btnAccount"
        Me.btnAccount.Size = New System.Drawing.Size(383, 53)
        Me.btnAccount.TabIndex = 9
        Me.btnAccount.Text = "Your Account"
        Me.btnAccount.UseVisualStyleBackColor = True
        '
        'grpStyle
        '
        Me.grpStyle.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.grpStyle.Controls.Add(Me.picWhiteVintage)
        Me.grpStyle.Controls.Add(Me.picWhiteRetro)
        Me.grpStyle.Controls.Add(Me.picWhite)
        Me.grpStyle.Controls.Add(Me.picPink)
        Me.grpStyle.Controls.Add(Me.rdbRetro)
        Me.grpStyle.Controls.Add(Me.rdbClassic)
        Me.grpStyle.Controls.Add(Me.rdbVintage)
        Me.grpStyle.Location = New System.Drawing.Point(67, 84)
        Me.grpStyle.Name = "grpStyle"
        Me.grpStyle.Size = New System.Drawing.Size(1103, 215)
        Me.grpStyle.TabIndex = 10
        Me.grpStyle.TabStop = False
        Me.grpStyle.Text = "Pick a Style"
        '
        'picWhiteVintage
        '
        Me.picWhiteVintage.Image = CType(resources.GetObject("picWhiteVintage.Image"), System.Drawing.Image)
        Me.picWhiteVintage.Location = New System.Drawing.Point(823, 21)
        Me.picWhiteVintage.Name = "picWhiteVintage"
        Me.picWhiteVintage.Size = New System.Drawing.Size(247, 161)
        Me.picWhiteVintage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picWhiteVintage.TabIndex = 31
        Me.picWhiteVintage.TabStop = False
        '
        'picWhiteRetro
        '
        Me.picWhiteRetro.Image = CType(resources.GetObject("picWhiteRetro.Image"), System.Drawing.Image)
        Me.picWhiteRetro.Location = New System.Drawing.Point(435, 21)
        Me.picWhiteRetro.Name = "picWhiteRetro"
        Me.picWhiteRetro.Size = New System.Drawing.Size(247, 161)
        Me.picWhiteRetro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picWhiteRetro.TabIndex = 30
        Me.picWhiteRetro.TabStop = False
        '
        'picWhite
        '
        Me.picWhite.Image = CType(resources.GetObject("picWhite.Image"), System.Drawing.Image)
        Me.picWhite.Location = New System.Drawing.Point(39, 21)
        Me.picWhite.Name = "picWhite"
        Me.picWhite.Size = New System.Drawing.Size(241, 161)
        Me.picWhite.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picWhite.TabIndex = 11
        Me.picWhite.TabStop = False
        '
        'picPink
        '
        Me.picPink.Image = CType(resources.GetObject("picPink.Image"), System.Drawing.Image)
        Me.picPink.Location = New System.Drawing.Point(513, 249)
        Me.picPink.Name = "picPink"
        Me.picPink.Size = New System.Drawing.Size(241, 161)
        Me.picPink.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picPink.TabIndex = 7
        Me.picPink.TabStop = False
        Me.picPink.Visible = False
        '
        'rdbRetro
        '
        Me.rdbRetro.AutoSize = True
        Me.rdbRetro.Location = New System.Drawing.Point(513, 188)
        Me.rdbRetro.Name = "rdbRetro"
        Me.rdbRetro.Size = New System.Drawing.Size(115, 21)
        Me.rdbRetro.TabIndex = 1
        Me.rdbRetro.TabStop = True
        Me.rdbRetro.Text = "Retro Runner"
        Me.rdbRetro.UseVisualStyleBackColor = True
        '
        'rdbClassic
        '
        Me.rdbClassic.AutoSize = True
        Me.rdbClassic.Location = New System.Drawing.Point(94, 188)
        Me.rdbClassic.Name = "rdbClassic"
        Me.rdbClassic.Size = New System.Drawing.Size(124, 21)
        Me.rdbClassic.TabIndex = 0
        Me.rdbClassic.TabStop = True
        Me.rdbClassic.Text = "Classic Runner"
        Me.rdbClassic.UseVisualStyleBackColor = True
        '
        'rdbVintage
        '
        Me.rdbVintage.AutoSize = True
        Me.rdbVintage.Location = New System.Drawing.Point(891, 188)
        Me.rdbVintage.Name = "rdbVintage"
        Me.rdbVintage.Size = New System.Drawing.Size(128, 21)
        Me.rdbVintage.TabIndex = 2
        Me.rdbVintage.TabStop = True
        Me.rdbVintage.Text = "Vintage Runner"
        Me.rdbVintage.UseVisualStyleBackColor = True
        '
        'grpDesign
        '
        Me.grpDesign.Controls.Add(Me.grpLogo)
        Me.grpDesign.Controls.Add(Me.grpSize)
        Me.grpDesign.Controls.Add(Me.btnNext)
        Me.grpDesign.Controls.Add(Me.lblAdditional)
        Me.grpDesign.Controls.Add(Me.cboHeelTab)
        Me.grpDesign.Controls.Add(Me.cboBackCounter)
        Me.grpDesign.Controls.Add(Me.cboQuarter)
        Me.grpDesign.Controls.Add(Me.cboVamp)
        Me.grpDesign.Controls.Add(Me.cboEyestay)
        Me.grpDesign.Controls.Add(Me.cboLaces)
        Me.grpDesign.Controls.Add(Me.lblHeelTab)
        Me.grpDesign.Controls.Add(Me.lblBackCounter)
        Me.grpDesign.Controls.Add(Me.lblQuarter)
        Me.grpDesign.Controls.Add(Me.lblVamp)
        Me.grpDesign.Controls.Add(Me.lblEyestay)
        Me.grpDesign.Controls.Add(Me.lblLaces)
        Me.grpDesign.Location = New System.Drawing.Point(67, 305)
        Me.grpDesign.Name = "grpDesign"
        Me.grpDesign.Size = New System.Drawing.Size(1103, 390)
        Me.grpDesign.TabIndex = 11
        Me.grpDesign.TabStop = False
        Me.grpDesign.Text = "Design"
        '
        'grpLogo
        '
        Me.grpLogo.Controls.Add(Me.lblLogo)
        Me.grpLogo.Controls.Add(Me.btnContinue)
        Me.grpLogo.Controls.Add(Me.rdbYes)
        Me.grpLogo.Controls.Add(Me.rdbNo)
        Me.grpLogo.Location = New System.Drawing.Point(409, 29)
        Me.grpLogo.Name = "grpLogo"
        Me.grpLogo.Size = New System.Drawing.Size(273, 257)
        Me.grpLogo.TabIndex = 19
        Me.grpLogo.TabStop = False
        Me.grpLogo.Text = "Logo"
        '
        'lblLogo
        '
        Me.lblLogo.AutoSize = True
        Me.lblLogo.Location = New System.Drawing.Point(28, 36)
        Me.lblLogo.Name = "lblLogo"
        Me.lblLogo.Size = New System.Drawing.Size(44, 17)
        Me.lblLogo.TabIndex = 4
        Me.lblLogo.Text = "Logo:"
        '
        'btnContinue
        '
        Me.btnContinue.Location = New System.Drawing.Point(145, 222)
        Me.btnContinue.Name = "btnContinue"
        Me.btnContinue.Size = New System.Drawing.Size(111, 29)
        Me.btnContinue.TabIndex = 18
        Me.btnContinue.Text = "Continue"
        Me.btnContinue.UseVisualStyleBackColor = True
        '
        'rdbYes
        '
        Me.rdbYes.AutoSize = True
        Me.rdbYes.Location = New System.Drawing.Point(122, 36)
        Me.rdbYes.Name = "rdbYes"
        Me.rdbYes.Size = New System.Drawing.Size(53, 21)
        Me.rdbYes.TabIndex = 15
        Me.rdbYes.TabStop = True
        Me.rdbYes.Text = "Yes"
        Me.rdbYes.UseVisualStyleBackColor = True
        '
        'rdbNo
        '
        Me.rdbNo.AutoSize = True
        Me.rdbNo.Location = New System.Drawing.Point(124, 75)
        Me.rdbNo.Name = "rdbNo"
        Me.rdbNo.Size = New System.Drawing.Size(47, 21)
        Me.rdbNo.TabIndex = 16
        Me.rdbNo.TabStop = True
        Me.rdbNo.Text = "No"
        Me.rdbNo.UseVisualStyleBackColor = True
        '
        'grpSize
        '
        Me.grpSize.Controls.Add(Me.cboFemale)
        Me.grpSize.Controls.Add(Me.cboMale)
        Me.grpSize.Controls.Add(Me.rdbFemale)
        Me.grpSize.Controls.Add(Me.rdbMale)
        Me.grpSize.Location = New System.Drawing.Point(711, 48)
        Me.grpSize.Name = "grpSize"
        Me.grpSize.Size = New System.Drawing.Size(371, 188)
        Me.grpSize.TabIndex = 17
        Me.grpSize.TabStop = False
        Me.grpSize.Text = "Size"
        Me.grpSize.Visible = False
        '
        'cboFemale
        '
        Me.cboFemale.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFemale.FormattingEnabled = True
        Me.cboFemale.Items.AddRange(New Object() {"EU 34", "EU 35", "EU 36", "EU 37", "EU 38", "EU 39", "EU 40", "EU 41", "EU 42", "EU 43", "EU 44", "EU 45"})
        Me.cboFemale.Location = New System.Drawing.Point(212, 120)
        Me.cboFemale.Name = "cboFemale"
        Me.cboFemale.Size = New System.Drawing.Size(121, 24)
        Me.cboFemale.TabIndex = 3
        Me.cboFemale.Visible = False
        '
        'cboMale
        '
        Me.cboMale.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboMale.FormattingEnabled = True
        Me.cboMale.Items.AddRange(New Object() {"EU 38", "EU 39", "EU 40", "EU 41", "EU 42", "EU 43", "EU 45", "EU 46", "EU 47", "EU 48", "EU 49"})
        Me.cboMale.Location = New System.Drawing.Point(212, 36)
        Me.cboMale.Name = "cboMale"
        Me.cboMale.Size = New System.Drawing.Size(121, 24)
        Me.cboMale.TabIndex = 2
        Me.cboMale.Visible = False
        '
        'rdbFemale
        '
        Me.rdbFemale.AutoSize = True
        Me.rdbFemale.Location = New System.Drawing.Point(51, 121)
        Me.rdbFemale.Name = "rdbFemale"
        Me.rdbFemale.Size = New System.Drawing.Size(75, 21)
        Me.rdbFemale.TabIndex = 1
        Me.rdbFemale.TabStop = True
        Me.rdbFemale.Text = "Female"
        Me.rdbFemale.UseVisualStyleBackColor = True
        '
        'rdbMale
        '
        Me.rdbMale.AutoSize = True
        Me.rdbMale.Location = New System.Drawing.Point(51, 39)
        Me.rdbMale.Name = "rdbMale"
        Me.rdbMale.Size = New System.Drawing.Size(59, 21)
        Me.rdbMale.TabIndex = 0
        Me.rdbMale.TabStop = True
        Me.rdbMale.Text = "Male"
        Me.rdbMale.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(924, 337)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(158, 37)
        Me.btnNext.TabIndex = 5
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'lblAdditional
        '
        Me.lblAdditional.AutoSize = True
        Me.lblAdditional.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdditional.Location = New System.Drawing.Point(35, 316)
        Me.lblAdditional.Name = "lblAdditional"
        Me.lblAdditional.Size = New System.Drawing.Size(480, 24)
        Me.lblAdditional.TabIndex = 14
        Me.lblAdditional.Text = "*If colour 'White' is selected there is no additional charge"
        '
        'cboHeelTab
        '
        Me.cboHeelTab.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboHeelTab.FormattingEnabled = True
        Me.cboHeelTab.Items.AddRange(New Object() {"White*", "Black", "Red", "Orange", "Yellow", "Green", "Blue"})
        Me.cboHeelTab.Location = New System.Drawing.Point(137, 258)
        Me.cboHeelTab.Name = "cboHeelTab"
        Me.cboHeelTab.Size = New System.Drawing.Size(217, 24)
        Me.cboHeelTab.TabIndex = 13
        '
        'cboBackCounter
        '
        Me.cboBackCounter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboBackCounter.FormattingEnabled = True
        Me.cboBackCounter.Items.AddRange(New Object() {"White*", "Black", "Red", "Orange", "Yellow", "Green", "Blue"})
        Me.cboBackCounter.Location = New System.Drawing.Point(137, 212)
        Me.cboBackCounter.Name = "cboBackCounter"
        Me.cboBackCounter.Size = New System.Drawing.Size(217, 24)
        Me.cboBackCounter.TabIndex = 12
        '
        'cboQuarter
        '
        Me.cboQuarter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboQuarter.FormattingEnabled = True
        Me.cboQuarter.Items.AddRange(New Object() {"White*", "Black", "Red", "Orange", "Yellow", "Green", "Blue"})
        Me.cboQuarter.Location = New System.Drawing.Point(137, 165)
        Me.cboQuarter.Name = "cboQuarter"
        Me.cboQuarter.Size = New System.Drawing.Size(217, 24)
        Me.cboQuarter.TabIndex = 10
        '
        'cboVamp
        '
        Me.cboVamp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboVamp.FormattingEnabled = True
        Me.cboVamp.Items.AddRange(New Object() {"White*", "Black", "Red", "Orange", "Yellow", "Green", "Blue"})
        Me.cboVamp.Location = New System.Drawing.Point(137, 119)
        Me.cboVamp.Name = "cboVamp"
        Me.cboVamp.Size = New System.Drawing.Size(217, 24)
        Me.cboVamp.TabIndex = 9
        '
        'cboEyestay
        '
        Me.cboEyestay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboEyestay.FormattingEnabled = True
        Me.cboEyestay.Items.AddRange(New Object() {"White*", "Black", "Red", "Orange", "Yellow", "Green", "Blue"})
        Me.cboEyestay.Location = New System.Drawing.Point(137, 75)
        Me.cboEyestay.Name = "cboEyestay"
        Me.cboEyestay.Size = New System.Drawing.Size(217, 24)
        Me.cboEyestay.TabIndex = 8
        '
        'cboLaces
        '
        Me.cboLaces.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboLaces.FormattingEnabled = True
        Me.cboLaces.Items.AddRange(New Object() {"White*", "Black", "Red", "Orange", "Yellow", "Green", "Blue"})
        Me.cboLaces.Location = New System.Drawing.Point(137, 29)
        Me.cboLaces.Name = "cboLaces"
        Me.cboLaces.Size = New System.Drawing.Size(217, 24)
        Me.cboLaces.TabIndex = 7
        '
        'lblHeelTab
        '
        Me.lblHeelTab.AutoSize = True
        Me.lblHeelTab.Location = New System.Drawing.Point(36, 265)
        Me.lblHeelTab.Name = "lblHeelTab"
        Me.lblHeelTab.Size = New System.Drawing.Size(70, 17)
        Me.lblHeelTab.TabIndex = 6
        Me.lblHeelTab.Text = "Heel Tab:"
        '
        'lblBackCounter
        '
        Me.lblBackCounter.AutoSize = True
        Me.lblBackCounter.Location = New System.Drawing.Point(36, 219)
        Me.lblBackCounter.Name = "lblBackCounter"
        Me.lblBackCounter.Size = New System.Drawing.Size(97, 17)
        Me.lblBackCounter.TabIndex = 5
        Me.lblBackCounter.Text = "Back Counter:"
        '
        'lblQuarter
        '
        Me.lblQuarter.AutoSize = True
        Me.lblQuarter.Location = New System.Drawing.Point(36, 172)
        Me.lblQuarter.Name = "lblQuarter"
        Me.lblQuarter.Size = New System.Drawing.Size(61, 17)
        Me.lblQuarter.TabIndex = 3
        Me.lblQuarter.Text = "Quarter:"
        '
        'lblVamp
        '
        Me.lblVamp.AutoSize = True
        Me.lblVamp.Location = New System.Drawing.Point(35, 126)
        Me.lblVamp.Name = "lblVamp"
        Me.lblVamp.Size = New System.Drawing.Size(48, 17)
        Me.lblVamp.TabIndex = 2
        Me.lblVamp.Text = "Vamp:"
        '
        'lblEyestay
        '
        Me.lblEyestay.AutoSize = True
        Me.lblEyestay.Location = New System.Drawing.Point(35, 82)
        Me.lblEyestay.Name = "lblEyestay"
        Me.lblEyestay.Size = New System.Drawing.Size(62, 17)
        Me.lblEyestay.TabIndex = 1
        Me.lblEyestay.Text = "Eyestay:"
        '
        'lblLaces
        '
        Me.lblLaces.AutoSize = True
        Me.lblLaces.Location = New System.Drawing.Point(35, 36)
        Me.lblLaces.Name = "lblLaces"
        Me.lblLaces.Size = New System.Drawing.Size(50, 17)
        Me.lblLaces.TabIndex = 0
        Me.lblLaces.Text = "Laces:"
        '
        'frmDesign
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.ClientSize = New System.Drawing.Size(1229, 696)
        Me.Controls.Add(Me.grpDesign)
        Me.Controls.Add(Me.grpStyle)
        Me.Controls.Add(Me.btnAccount)
        Me.Controls.Add(Me.btnCustomize)
        Me.Controls.Add(Me.btnHome)
        Me.Name = "frmDesign"
        Me.Text = "Design"
        Me.grpStyle.ResumeLayout(False)
        Me.grpStyle.PerformLayout()
        CType(Me.picWhiteVintage, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picWhiteRetro, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picWhite, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPink, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpDesign.ResumeLayout(False)
        Me.grpDesign.PerformLayout()
        Me.grpLogo.ResumeLayout(False)
        Me.grpLogo.PerformLayout()
        Me.grpSize.ResumeLayout(False)
        Me.grpSize.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnHome As Button
    Friend WithEvents btnCustomize As Button
    Friend WithEvents btnAccount As Button
    Friend WithEvents grpStyle As GroupBox
    Friend WithEvents picWhite As PictureBox
    Friend WithEvents picPink As PictureBox
    Friend WithEvents rdbRetro As RadioButton
    Friend WithEvents rdbClassic As RadioButton
    Friend WithEvents rdbVintage As RadioButton
    Friend WithEvents grpDesign As GroupBox
    Friend WithEvents btnContinue As Button
    Friend WithEvents grpSize As GroupBox
    Friend WithEvents cboFemale As ComboBox
    Friend WithEvents cboMale As ComboBox
    Friend WithEvents rdbFemale As RadioButton
    Friend WithEvents rdbMale As RadioButton
    Friend WithEvents rdbNo As RadioButton
    Friend WithEvents btnNext As Button
    Friend WithEvents rdbYes As RadioButton
    Friend WithEvents lblAdditional As Label
    Friend WithEvents cboHeelTab As ComboBox
    Friend WithEvents cboBackCounter As ComboBox
    Friend WithEvents cboQuarter As ComboBox
    Friend WithEvents cboVamp As ComboBox
    Friend WithEvents cboEyestay As ComboBox
    Friend WithEvents cboLaces As ComboBox
    Friend WithEvents lblHeelTab As Label
    Friend WithEvents lblBackCounter As Label
    Friend WithEvents lblLogo As Label
    Friend WithEvents lblQuarter As Label
    Friend WithEvents lblVamp As Label
    Friend WithEvents lblEyestay As Label
    Friend WithEvents lblLaces As Label
    Friend WithEvents picWhiteVintage As PictureBox
    Friend WithEvents picWhiteRetro As PictureBox
    Friend WithEvents grpLogo As GroupBox
End Class
