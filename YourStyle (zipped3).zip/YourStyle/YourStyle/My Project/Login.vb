﻿Public Class frmLogin

    'We worked well as a group and delegated all the work

    'Ailíse Ryan 119396633 - Ailíse did the customer side of things; if you log in as a customer etc
    'She also got everyones indiviudal work and put it together and briefly desgined it to make this program

    'Paul Drinan 119451216 - Paul worked on the manager/owner side of the program; if you log in as the owner manager that is his work
    'He also worked on the user manual

    'Diarmuid Hurley 119376016 - Diarmuid worked on the login and the register for this program and at the end made sure the program
    'worked for definate

    'Michael Hammett 119472154 - Michael worked on the employee side of things; what you would see if the employee log into this program 
    'and how they can work


    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LoginDataSet.Login' table. You can move, or remove it, as needed.
        Me.LoginTableAdapter.Fill(Me.LoginDataSet.Login)
        txtUsername.Focus()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtUsername.Clear()
        txtPassword.Clear()
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        frmRegister.Show()
        txtUsername.Clear()
        txtPassword.Clear()
        Me.Hide()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        Dim queryUser = From Login In LoginDataSet.Login
                        Where Login.Username = txtUsername.Text
                        Select Login.Username

        Dim queryPass = From Login In LoginDataSet.Login
                        Where Login.Password = txtPassword.Text
                        Select Login.Password

        Dim FoDUsername = queryUser.FirstOrDefault()
        Dim FoDPassword = queryPass.FirstOrDefault()

        If txtUsername.Text = "" Then
            MessageBox.Show("Please enter a username", "Error")
            txtUsername.Focus()
        ElseIf txtPassword.Text = "" Then
            MessageBox.Show("Please enter a password", "Error")
            txtPassword.Focus()
        ElseIf FoDUsername.ToString() <> txtUsername.Text And
           FoDPassword.ToString() <> txtPassword.Text Then
            MessageBox.Show("Incorrect Username or Password", "Error")
        ElseIf FoDUsername.ToString() = txtUsername.Text And
           FoDPassword.ToString() = txtPassword.Text Then
            MessageBox.Show("Login Successful")
            Me.Hide()
            'Next form needs to be put in here
        End If

    End Sub
End Class