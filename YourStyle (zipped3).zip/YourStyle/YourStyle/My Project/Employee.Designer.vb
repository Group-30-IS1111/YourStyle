﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmEmployee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Contact_NumberLabel As System.Windows.Forms.Label
        Dim PostcodeLabel As System.Windows.Forms.Label
        Dim AddressLabel As System.Windows.Forms.Label
        Dim AgeLabel As System.Windows.Forms.Label
        Dim NameLabel As System.Windows.Forms.Label
        Dim Product_IDLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmEmployee))
        Me.BindingNavigator1 = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.IS1111_Project_DatabaseDataSet = New YourStyle.IS1111_Project_DatabaseDataSet()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnUpdate = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.rdoChangeStatus = New System.Windows.Forms.RadioButton()
        Me.lblCustomerDetails = New System.Windows.Forms.Label()
        Me.btnViewProductProgress = New System.Windows.Forms.Button()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Contact_NumberTextBox = New System.Windows.Forms.TextBox()
        Me.PostcodeTextBox = New System.Windows.Forms.TextBox()
        Me.AddressTextBox = New System.Windows.Forms.TextBox()
        Me.AgeTextBox = New System.Windows.Forms.TextBox()
        Me.NameTextBox = New System.Windows.Forms.TextBox()
        Me.Product_IDTextBox = New System.Windows.Forms.TextBox()
        Me.grpCustomer = New System.Windows.Forms.GroupBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Customer_DetailsTableAdapter = New YourStyle.IS1111_Project_DatabaseDataSetTableAdapters.Customer_DetailsTableAdapter()
        Me.Customer_DetailsTableAdapter1 = New YourStyle.IS1111_Project_DatabaseDataSet2TableAdapters.Customer_DetailsTableAdapter()
        Me.Customer_DetailsTableAdapter2 = New YourStyle.IS1111_Project_DatabaseDataSet1TableAdapters.Customer_DetailsTableAdapter()
        Me.btnlogOut = New System.Windows.Forms.Button()
        Me.CustomerDetailsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Contact_NumberLabel = New System.Windows.Forms.Label()
        PostcodeLabel = New System.Windows.Forms.Label()
        AddressLabel = New System.Windows.Forms.Label()
        AgeLabel = New System.Windows.Forms.Label()
        NameLabel = New System.Windows.Forms.Label()
        Product_IDLabel = New System.Windows.Forms.Label()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BindingNavigator1.SuspendLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.IS1111_Project_DatabaseDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpCustomer.SuspendLayout()
        CType(Me.CustomerDetailsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Contact_NumberLabel
        '
        Contact_NumberLabel.AutoSize = True
        Contact_NumberLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Contact_NumberLabel.Location = New System.Drawing.Point(24, 282)
        Contact_NumberLabel.Name = "Contact_NumberLabel"
        Contact_NumberLabel.Size = New System.Drawing.Size(136, 20)
        Contact_NumberLabel.TabIndex = 53
        Contact_NumberLabel.Text = "Contact Number:"
        '
        'PostcodeLabel
        '
        PostcodeLabel.AutoSize = True
        PostcodeLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        PostcodeLabel.Location = New System.Drawing.Point(24, 223)
        PostcodeLabel.Name = "PostcodeLabel"
        PostcodeLabel.Size = New System.Drawing.Size(84, 20)
        PostcodeLabel.TabIndex = 51
        PostcodeLabel.Text = "Postcode:"
        '
        'AddressLabel
        '
        AddressLabel.AutoSize = True
        AddressLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        AddressLabel.Location = New System.Drawing.Point(24, 163)
        AddressLabel.Name = "AddressLabel"
        AddressLabel.Size = New System.Drawing.Size(76, 20)
        AddressLabel.TabIndex = 49
        AddressLabel.Text = "Address:"
        '
        'AgeLabel
        '
        AgeLabel.AutoSize = True
        AgeLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        AgeLabel.Location = New System.Drawing.Point(24, 108)
        AgeLabel.Name = "AgeLabel"
        AgeLabel.Size = New System.Drawing.Size(43, 20)
        AgeLabel.TabIndex = 47
        AgeLabel.Text = "Age:"
        '
        'NameLabel
        '
        NameLabel.AutoSize = True
        NameLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NameLabel.Location = New System.Drawing.Point(24, 56)
        NameLabel.Name = "NameLabel"
        NameLabel.Size = New System.Drawing.Size(58, 20)
        NameLabel.TabIndex = 45
        NameLabel.Text = "Name:"
        '
        'Product_IDLabel
        '
        Product_IDLabel.AutoSize = True
        Product_IDLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Product_IDLabel.Location = New System.Drawing.Point(24, 334)
        Product_IDLabel.Name = "Product_IDLabel"
        Product_IDLabel.Size = New System.Drawing.Size(94, 20)
        Product_IDLabel.TabIndex = 43
        Product_IDLabel.Text = "Product ID:"
        '
        'BindingNavigator1
        '
        Me.BindingNavigator1.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.BindingNavigator1.BindingSource = Me.BindingSource1
        Me.BindingNavigator1.CountItem = Me.BindingNavigatorCountItem
        Me.BindingNavigator1.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.BindingNavigator1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.BindingNavigator1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.btnUpdate, Me.ToolStripTextBox1})
        Me.BindingNavigator1.Location = New System.Drawing.Point(0, 0)
        Me.BindingNavigator1.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.BindingNavigator1.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.BindingNavigator1.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.BindingNavigator1.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.BindingNavigator1.Name = "BindingNavigator1"
        Me.BindingNavigator1.PositionItem = Me.BindingNavigatorPositionItem
        Me.BindingNavigator1.Size = New System.Drawing.Size(696, 31)
        Me.BindingNavigator1.TabIndex = 1
        Me.BindingNavigator1.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(28, 28)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingSource1
        '
        Me.BindingSource1.DataMember = "Customer Details"
        Me.BindingSource1.DataSource = Me.IS1111_Project_DatabaseDataSet
        '
        'IS1111_Project_DatabaseDataSet
        '
        Me.IS1111_Project_DatabaseDataSet.DataSetName = "IS1111_Project_DatabaseDataSet"
        Me.IS1111_Project_DatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(45, 28)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(28, 28)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(28, 28)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(28, 28)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 31)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(45, 27)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 31)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(28, 28)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(28, 28)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 31)
        '
        'btnUpdate
        '
        Me.btnUpdate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnUpdate.Image = CType(resources.GetObject("btnUpdate.Image"), System.Drawing.Image)
        Me.btnUpdate.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnUpdate.MergeIndex = 6
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(28, 28)
        Me.btnUpdate.Text = "ToolStripButton1"
        '
        'ToolStripTextBox1
        '
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        Me.ToolStripTextBox1.Size = New System.Drawing.Size(100, 31)
        '
        'rdoChangeStatus
        '
        Me.rdoChangeStatus.AutoSize = True
        Me.rdoChangeStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoChangeStatus.Location = New System.Drawing.Point(99, 422)
        Me.rdoChangeStatus.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.rdoChangeStatus.Name = "rdoChangeStatus"
        Me.rdoChangeStatus.Size = New System.Drawing.Size(199, 24)
        Me.rdoChangeStatus.TabIndex = 7
        Me.rdoChangeStatus.TabStop = True
        Me.rdoChangeStatus.Text = "Update Product Status"
        Me.rdoChangeStatus.UseVisualStyleBackColor = True
        '
        'lblCustomerDetails
        '
        Me.lblCustomerDetails.BackColor = System.Drawing.Color.Transparent
        Me.lblCustomerDetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCustomerDetails.ForeColor = System.Drawing.Color.Black
        Me.lblCustomerDetails.Location = New System.Drawing.Point(77, 49)
        Me.lblCustomerDetails.Name = "lblCustomerDetails"
        Me.lblCustomerDetails.Size = New System.Drawing.Size(177, 40)
        Me.lblCustomerDetails.TabIndex = 57
        Me.lblCustomerDetails.Text = "Customer Details"
        Me.lblCustomerDetails.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnViewProductProgress
        '
        Me.btnViewProductProgress.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btnViewProductProgress.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnViewProductProgress.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewProductProgress.Location = New System.Drawing.Point(55, 369)
        Me.btnViewProductProgress.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnViewProductProgress.Name = "btnViewProductProgress"
        Me.btnViewProductProgress.Size = New System.Drawing.Size(162, 34)
        Me.btnViewProductProgress.TabIndex = 6
        Me.btnViewProductProgress.Text = "View Product Progress"
        Me.btnViewProductProgress.UseVisualStyleBackColor = False
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(247, 384)
        Me.ProgressBar1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(141, 19)
        Me.ProgressBar1.TabIndex = 55
        '
        'Contact_NumberTextBox
        '
        Me.Contact_NumberTextBox.Location = New System.Drawing.Point(200, 280)
        Me.Contact_NumberTextBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Contact_NumberTextBox.Name = "Contact_NumberTextBox"
        Me.Contact_NumberTextBox.Size = New System.Drawing.Size(161, 22)
        Me.Contact_NumberTextBox.TabIndex = 4
        '
        'PostcodeTextBox
        '
        Me.PostcodeTextBox.Location = New System.Drawing.Point(200, 223)
        Me.PostcodeTextBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PostcodeTextBox.Name = "PostcodeTextBox"
        Me.PostcodeTextBox.Size = New System.Drawing.Size(161, 22)
        Me.PostcodeTextBox.TabIndex = 3
        '
        'AddressTextBox
        '
        Me.AddressTextBox.Location = New System.Drawing.Point(200, 163)
        Me.AddressTextBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.AddressTextBox.Name = "AddressTextBox"
        Me.AddressTextBox.Size = New System.Drawing.Size(161, 22)
        Me.AddressTextBox.TabIndex = 2
        '
        'AgeTextBox
        '
        Me.AgeTextBox.Location = New System.Drawing.Point(200, 108)
        Me.AgeTextBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.AgeTextBox.Name = "AgeTextBox"
        Me.AgeTextBox.Size = New System.Drawing.Size(161, 22)
        Me.AgeTextBox.TabIndex = 1
        '
        'NameTextBox
        '
        Me.NameTextBox.Location = New System.Drawing.Point(200, 54)
        Me.NameTextBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NameTextBox.Name = "NameTextBox"
        Me.NameTextBox.Size = New System.Drawing.Size(161, 22)
        Me.NameTextBox.TabIndex = 0
        '
        'Product_IDTextBox
        '
        Me.Product_IDTextBox.Location = New System.Drawing.Point(200, 334)
        Me.Product_IDTextBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Product_IDTextBox.Name = "Product_IDTextBox"
        Me.Product_IDTextBox.Size = New System.Drawing.Size(161, 22)
        Me.Product_IDTextBox.TabIndex = 5
        '
        'grpCustomer
        '
        Me.grpCustomer.Controls.Add(Me.btnlogOut)
        Me.grpCustomer.Controls.Add(Me.NameTextBox)
        Me.grpCustomer.Controls.Add(NameLabel)
        Me.grpCustomer.Controls.Add(Me.rdoChangeStatus)
        Me.grpCustomer.Controls.Add(Me.AgeTextBox)
        Me.grpCustomer.Controls.Add(AgeLabel)
        Me.grpCustomer.Controls.Add(Me.ProgressBar1)
        Me.grpCustomer.Controls.Add(Me.btnViewProductProgress)
        Me.grpCustomer.Controls.Add(AddressLabel)
        Me.grpCustomer.Controls.Add(PostcodeLabel)
        Me.grpCustomer.Controls.Add(Me.Product_IDTextBox)
        Me.grpCustomer.Controls.Add(Product_IDLabel)
        Me.grpCustomer.Controls.Add(Me.Contact_NumberTextBox)
        Me.grpCustomer.Controls.Add(Contact_NumberLabel)
        Me.grpCustomer.Controls.Add(Me.PostcodeTextBox)
        Me.grpCustomer.Controls.Add(Me.AddressTextBox)
        Me.grpCustomer.Location = New System.Drawing.Point(82, 92)
        Me.grpCustomer.Name = "grpCustomer"
        Me.grpCustomer.Size = New System.Drawing.Size(510, 454)
        Me.grpCustomer.TabIndex = 60
        Me.grpCustomer.TabStop = False
        '
        'Timer1
        '
        '
        'Customer_DetailsTableAdapter
        '
        Me.Customer_DetailsTableAdapter.ClearBeforeFill = True
        '
        'Customer_DetailsTableAdapter1
        '
        Me.Customer_DetailsTableAdapter1.ClearBeforeFill = True
        '
        'Customer_DetailsTableAdapter2
        '
        Me.Customer_DetailsTableAdapter2.ClearBeforeFill = True
        '
        'btnlogOut
        '
        Me.btnlogOut.Location = New System.Drawing.Point(405, 414)
        Me.btnlogOut.Name = "btnlogOut"
        Me.btnlogOut.Size = New System.Drawing.Size(99, 32)
        Me.btnlogOut.TabIndex = 8
        Me.btnlogOut.Text = "Log Out"
        Me.btnlogOut.UseVisualStyleBackColor = True
        '
        'frmEmployee
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.ClientSize = New System.Drawing.Size(696, 568)
        Me.Controls.Add(Me.grpCustomer)
        Me.Controls.Add(Me.lblCustomerDetails)
        Me.Controls.Add(Me.BindingNavigator1)
        Me.Name = "frmEmployee"
        Me.Text = "Employee"
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BindingNavigator1.ResumeLayout(False)
        Me.BindingNavigator1.PerformLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.IS1111_Project_DatabaseDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpCustomer.ResumeLayout(False)
        Me.grpCustomer.PerformLayout()
        CType(Me.CustomerDetailsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BindingNavigator1 As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents btnUpdate As ToolStripButton
    Friend WithEvents rdoChangeStatus As RadioButton
    Friend WithEvents lblCustomerDetails As Label
    Friend WithEvents btnViewProductProgress As Button
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents Contact_NumberTextBox As TextBox
    Friend WithEvents PostcodeTextBox As TextBox
    Friend WithEvents AddressTextBox As TextBox
    Friend WithEvents AgeTextBox As TextBox
    Friend WithEvents NameTextBox As TextBox
    Friend WithEvents Product_IDTextBox As TextBox
    Friend WithEvents grpCustomer As GroupBox
    Friend WithEvents CustomerDetailsBindingSource As BindingSource
    Friend WithEvents Timer1 As Timer
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents IS1111_Project_DatabaseDataSet As IS1111_Project_DatabaseDataSet
    Friend WithEvents Customer_DetailsTableAdapter As IS1111_Project_DatabaseDataSetTableAdapters.Customer_DetailsTableAdapter
    Friend WithEvents Customer_DetailsTableAdapter1 As IS1111_Project_DatabaseDataSet2TableAdapters.Customer_DetailsTableAdapter
    Friend WithEvents ToolStripTextBox1 As ToolStripTextBox
    Friend WithEvents Customer_DetailsTableAdapter2 As IS1111_Project_DatabaseDataSet1TableAdapters.Customer_DetailsTableAdapter
    Friend WithEvents btnlogOut As Button
End Class
