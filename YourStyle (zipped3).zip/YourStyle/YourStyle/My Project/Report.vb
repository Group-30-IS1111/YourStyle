﻿Public Class frmReport
    Private Sub Report_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'ReportDataSet.Report_2019' table. You can move, or remove it, as needed.
        Me.Report_2019TableAdapter.Fill(Me.ReportDataSet.Report_2019)

    End Sub

    Private Sub btnQuery_Click(sender As Object, e As EventArgs) Handles btnQuery.Click
        Me.Hide()
        frmQuery.Show()
    End Sub

    Private Sub btnStaff_Click(sender As Object, e As EventArgs) Handles btnStaff.Click
        Me.Hide()
        frmStaff.Show()
    End Sub

    Private Sub btnOrders_Click(sender As Object, e As EventArgs) Handles btnOrders.Click
        Me.Hide()
        frmOrders.Show()
    End Sub

    Private Sub btnMenu_Click(sender As Object, e As EventArgs) Handles btnMenu.Click
        Me.Hide()
        frmMenu.Show()
    End Sub
End Class