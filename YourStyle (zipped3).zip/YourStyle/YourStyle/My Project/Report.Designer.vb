﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnMenu = New System.Windows.Forms.Button()
        Me.btnReports = New System.Windows.Forms.Button()
        Me.btnQuery = New System.Windows.Forms.Button()
        Me.btnStaff = New System.Windows.Forms.Button()
        Me.btnOrders = New System.Windows.Forms.Button()
        Me.grpReports = New System.Windows.Forms.GroupBox()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.MonthDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SalesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ClassicShoesSoldDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VintageShoesSoldDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RetroShoesSoldDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.QuatersCustomizedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VampsCustomizedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EyestraysCustomizedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HeelTabsCustomizedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HeelBackCountersCustomizedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LacesCustomizedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LogosCustomizedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LogosNotProvidedByCustomiersDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TextAddedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AdditionalTextAddedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalSalesexcVATDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalVATDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalSalesincVATDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Report2019BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ReportDataSet = New YourStyle.ReportDataSet()
        Me.Report_2019TableAdapter = New YourStyle.ReportDataSetTableAdapters.Report_2019TableAdapter()
        Me.grpReports.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Report2019BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReportDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnMenu
        '
        Me.btnMenu.Location = New System.Drawing.Point(12, 26)
        Me.btnMenu.Name = "btnMenu"
        Me.btnMenu.Size = New System.Drawing.Size(250, 39)
        Me.btnMenu.TabIndex = 2
        Me.btnMenu.Text = "Menu"
        Me.btnMenu.UseVisualStyleBackColor = True
        '
        'btnReports
        '
        Me.btnReports.Location = New System.Drawing.Point(261, 26)
        Me.btnReports.Name = "btnReports"
        Me.btnReports.Size = New System.Drawing.Size(250, 39)
        Me.btnReports.TabIndex = 3
        Me.btnReports.Text = "Reports"
        Me.btnReports.UseVisualStyleBackColor = True
        '
        'btnQuery
        '
        Me.btnQuery.Location = New System.Drawing.Point(507, 26)
        Me.btnQuery.Name = "btnQuery"
        Me.btnQuery.Size = New System.Drawing.Size(250, 39)
        Me.btnQuery.TabIndex = 4
        Me.btnQuery.Text = "Query"
        Me.btnQuery.UseVisualStyleBackColor = True
        '
        'btnStaff
        '
        Me.btnStaff.Location = New System.Drawing.Point(748, 26)
        Me.btnStaff.Name = "btnStaff"
        Me.btnStaff.Size = New System.Drawing.Size(250, 39)
        Me.btnStaff.TabIndex = 5
        Me.btnStaff.Text = "Staff"
        Me.btnStaff.UseVisualStyleBackColor = True
        '
        'btnOrders
        '
        Me.btnOrders.Location = New System.Drawing.Point(995, 26)
        Me.btnOrders.Name = "btnOrders"
        Me.btnOrders.Size = New System.Drawing.Size(250, 39)
        Me.btnOrders.TabIndex = 6
        Me.btnOrders.Text = "Orders"
        Me.btnOrders.UseVisualStyleBackColor = True
        '
        'grpReports
        '
        Me.grpReports.Controls.Add(Me.btnPrint)
        Me.grpReports.Controls.Add(Me.DataGridView1)
        Me.grpReports.Location = New System.Drawing.Point(116, 71)
        Me.grpReports.Name = "grpReports"
        Me.grpReports.Size = New System.Drawing.Size(1010, 440)
        Me.grpReports.TabIndex = 7
        Me.grpReports.TabStop = False
        Me.grpReports.Text = "Reports"
        '
        'btnPrint
        '
        Me.btnPrint.Location = New System.Drawing.Point(781, 327)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(201, 55)
        Me.btnPrint.TabIndex = 1
        Me.btnPrint.Text = "Print"
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.MonthDataGridViewTextBoxColumn, Me.SalesDataGridViewTextBoxColumn, Me.ClassicShoesSoldDataGridViewTextBoxColumn, Me.VintageShoesSoldDataGridViewTextBoxColumn, Me.RetroShoesSoldDataGridViewTextBoxColumn, Me.QuatersCustomizedDataGridViewTextBoxColumn, Me.VampsCustomizedDataGridViewTextBoxColumn, Me.EyestraysCustomizedDataGridViewTextBoxColumn, Me.HeelTabsCustomizedDataGridViewTextBoxColumn, Me.HeelBackCountersCustomizedDataGridViewTextBoxColumn, Me.LacesCustomizedDataGridViewTextBoxColumn, Me.LogosCustomizedDataGridViewTextBoxColumn, Me.LogosNotProvidedByCustomiersDataGridViewTextBoxColumn, Me.TextAddedDataGridViewTextBoxColumn, Me.AdditionalTextAddedDataGridViewTextBoxColumn, Me.TotalSalesexcVATDataGridViewTextBoxColumn, Me.TotalVATDataGridViewTextBoxColumn, Me.TotalSalesincVATDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.Report2019BindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(37, 49)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(885, 219)
        Me.DataGridView1.TabIndex = 0
        '
        'MonthDataGridViewTextBoxColumn
        '
        Me.MonthDataGridViewTextBoxColumn.DataPropertyName = "Month"
        Me.MonthDataGridViewTextBoxColumn.HeaderText = "Month"
        Me.MonthDataGridViewTextBoxColumn.Name = "MonthDataGridViewTextBoxColumn"
        '
        'SalesDataGridViewTextBoxColumn
        '
        Me.SalesDataGridViewTextBoxColumn.DataPropertyName = "Sales"
        Me.SalesDataGridViewTextBoxColumn.HeaderText = "Sales"
        Me.SalesDataGridViewTextBoxColumn.Name = "SalesDataGridViewTextBoxColumn"
        '
        'ClassicShoesSoldDataGridViewTextBoxColumn
        '
        Me.ClassicShoesSoldDataGridViewTextBoxColumn.DataPropertyName = "Classic Shoes Sold"
        Me.ClassicShoesSoldDataGridViewTextBoxColumn.HeaderText = "Classic Shoes Sold"
        Me.ClassicShoesSoldDataGridViewTextBoxColumn.Name = "ClassicShoesSoldDataGridViewTextBoxColumn"
        '
        'VintageShoesSoldDataGridViewTextBoxColumn
        '
        Me.VintageShoesSoldDataGridViewTextBoxColumn.DataPropertyName = "Vintage Shoes Sold"
        Me.VintageShoesSoldDataGridViewTextBoxColumn.HeaderText = "Vintage Shoes Sold"
        Me.VintageShoesSoldDataGridViewTextBoxColumn.Name = "VintageShoesSoldDataGridViewTextBoxColumn"
        '
        'RetroShoesSoldDataGridViewTextBoxColumn
        '
        Me.RetroShoesSoldDataGridViewTextBoxColumn.DataPropertyName = "Retro Shoes Sold"
        Me.RetroShoesSoldDataGridViewTextBoxColumn.HeaderText = "Retro Shoes Sold"
        Me.RetroShoesSoldDataGridViewTextBoxColumn.Name = "RetroShoesSoldDataGridViewTextBoxColumn"
        '
        'QuatersCustomizedDataGridViewTextBoxColumn
        '
        Me.QuatersCustomizedDataGridViewTextBoxColumn.DataPropertyName = "Quaters Customized"
        Me.QuatersCustomizedDataGridViewTextBoxColumn.HeaderText = "Quaters Customized"
        Me.QuatersCustomizedDataGridViewTextBoxColumn.Name = "QuatersCustomizedDataGridViewTextBoxColumn"
        '
        'VampsCustomizedDataGridViewTextBoxColumn
        '
        Me.VampsCustomizedDataGridViewTextBoxColumn.DataPropertyName = "Vamps Customized"
        Me.VampsCustomizedDataGridViewTextBoxColumn.HeaderText = "Vamps Customized"
        Me.VampsCustomizedDataGridViewTextBoxColumn.Name = "VampsCustomizedDataGridViewTextBoxColumn"
        '
        'EyestraysCustomizedDataGridViewTextBoxColumn
        '
        Me.EyestraysCustomizedDataGridViewTextBoxColumn.DataPropertyName = "Eyestrays Customized"
        Me.EyestraysCustomizedDataGridViewTextBoxColumn.HeaderText = "Eyestrays Customized"
        Me.EyestraysCustomizedDataGridViewTextBoxColumn.Name = "EyestraysCustomizedDataGridViewTextBoxColumn"
        '
        'HeelTabsCustomizedDataGridViewTextBoxColumn
        '
        Me.HeelTabsCustomizedDataGridViewTextBoxColumn.DataPropertyName = "Heel Tabs Customized"
        Me.HeelTabsCustomizedDataGridViewTextBoxColumn.HeaderText = "Heel Tabs Customized"
        Me.HeelTabsCustomizedDataGridViewTextBoxColumn.Name = "HeelTabsCustomizedDataGridViewTextBoxColumn"
        '
        'HeelBackCountersCustomizedDataGridViewTextBoxColumn
        '
        Me.HeelBackCountersCustomizedDataGridViewTextBoxColumn.DataPropertyName = "Heel/ Back Counters Customized"
        Me.HeelBackCountersCustomizedDataGridViewTextBoxColumn.HeaderText = "Heel/ Back Counters Customized"
        Me.HeelBackCountersCustomizedDataGridViewTextBoxColumn.Name = "HeelBackCountersCustomizedDataGridViewTextBoxColumn"
        '
        'LacesCustomizedDataGridViewTextBoxColumn
        '
        Me.LacesCustomizedDataGridViewTextBoxColumn.DataPropertyName = "Laces Customized"
        Me.LacesCustomizedDataGridViewTextBoxColumn.HeaderText = "Laces Customized"
        Me.LacesCustomizedDataGridViewTextBoxColumn.Name = "LacesCustomizedDataGridViewTextBoxColumn"
        '
        'LogosCustomizedDataGridViewTextBoxColumn
        '
        Me.LogosCustomizedDataGridViewTextBoxColumn.DataPropertyName = "Logos Customized"
        Me.LogosCustomizedDataGridViewTextBoxColumn.HeaderText = "Logos Customized"
        Me.LogosCustomizedDataGridViewTextBoxColumn.Name = "LogosCustomizedDataGridViewTextBoxColumn"
        '
        'LogosNotProvidedByCustomiersDataGridViewTextBoxColumn
        '
        Me.LogosNotProvidedByCustomiersDataGridViewTextBoxColumn.DataPropertyName = "Logos Not Provided By Customiers"
        Me.LogosNotProvidedByCustomiersDataGridViewTextBoxColumn.HeaderText = "Logos Not Provided By Customiers"
        Me.LogosNotProvidedByCustomiersDataGridViewTextBoxColumn.Name = "LogosNotProvidedByCustomiersDataGridViewTextBoxColumn"
        '
        'TextAddedDataGridViewTextBoxColumn
        '
        Me.TextAddedDataGridViewTextBoxColumn.DataPropertyName = "Text Added"
        Me.TextAddedDataGridViewTextBoxColumn.HeaderText = "Text Added"
        Me.TextAddedDataGridViewTextBoxColumn.Name = "TextAddedDataGridViewTextBoxColumn"
        '
        'AdditionalTextAddedDataGridViewTextBoxColumn
        '
        Me.AdditionalTextAddedDataGridViewTextBoxColumn.DataPropertyName = "Additional Text Added"
        Me.AdditionalTextAddedDataGridViewTextBoxColumn.HeaderText = "Additional Text Added"
        Me.AdditionalTextAddedDataGridViewTextBoxColumn.Name = "AdditionalTextAddedDataGridViewTextBoxColumn"
        '
        'TotalSalesexcVATDataGridViewTextBoxColumn
        '
        Me.TotalSalesexcVATDataGridViewTextBoxColumn.DataPropertyName = "Total Sales (exc VAT)"
        Me.TotalSalesexcVATDataGridViewTextBoxColumn.HeaderText = "Total Sales (exc VAT)"
        Me.TotalSalesexcVATDataGridViewTextBoxColumn.Name = "TotalSalesexcVATDataGridViewTextBoxColumn"
        '
        'TotalVATDataGridViewTextBoxColumn
        '
        Me.TotalVATDataGridViewTextBoxColumn.DataPropertyName = "Total VAT"
        Me.TotalVATDataGridViewTextBoxColumn.HeaderText = "Total VAT"
        Me.TotalVATDataGridViewTextBoxColumn.Name = "TotalVATDataGridViewTextBoxColumn"
        '
        'TotalSalesincVATDataGridViewTextBoxColumn
        '
        Me.TotalSalesincVATDataGridViewTextBoxColumn.DataPropertyName = "Total Sales (inc VAT)"
        Me.TotalSalesincVATDataGridViewTextBoxColumn.HeaderText = "Total Sales (inc VAT)"
        Me.TotalSalesincVATDataGridViewTextBoxColumn.Name = "TotalSalesincVATDataGridViewTextBoxColumn"
        '
        'Report2019BindingSource
        '
        Me.Report2019BindingSource.DataMember = "Report 2019"
        Me.Report2019BindingSource.DataSource = Me.ReportDataSet
        '
        'ReportDataSet
        '
        Me.ReportDataSet.DataSetName = "ReportDataSet"
        Me.ReportDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Report_2019TableAdapter
        '
        Me.Report_2019TableAdapter.ClearBeforeFill = True
        '
        'frmReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.ClientSize = New System.Drawing.Size(1246, 592)
        Me.Controls.Add(Me.grpReports)
        Me.Controls.Add(Me.btnOrders)
        Me.Controls.Add(Me.btnStaff)
        Me.Controls.Add(Me.btnQuery)
        Me.Controls.Add(Me.btnReports)
        Me.Controls.Add(Me.btnMenu)
        Me.Name = "frmReport"
        Me.Text = "Report"
        Me.grpReports.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Report2019BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReportDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnMenu As Button
    Friend WithEvents btnReports As Button
    Friend WithEvents btnQuery As Button
    Friend WithEvents btnStaff As Button
    Friend WithEvents btnOrders As Button
    Friend WithEvents grpReports As GroupBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents ReportDataSet As ReportDataSet
    Friend WithEvents Report2019BindingSource As BindingSource
    Friend WithEvents Report_2019TableAdapter As ReportDataSetTableAdapters.Report_2019TableAdapter
    Friend WithEvents MonthDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SalesDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ClassicShoesSoldDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents VintageShoesSoldDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RetroShoesSoldDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents QuatersCustomizedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents VampsCustomizedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EyestraysCustomizedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HeelTabsCustomizedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HeelBackCountersCustomizedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LacesCustomizedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LogosCustomizedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LogosNotProvidedByCustomiersDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TextAddedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AdditionalTextAddedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TotalSalesexcVATDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TotalVATDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TotalSalesincVATDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents btnPrint As Button
End Class
