﻿Public Class frmOrders
    Private Sub Orders_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Your_StyleDataSet2.Customers_Orders' table. You can move, or remove it, as needed.
        Me.Customers_OrdersTableAdapter.Fill(Me.Your_StyleDataSet2.Customers_Orders)

    End Sub
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        If txtCustomer.Text = "" Then
            Call NotFound()
            Exit Sub
        Else

            BindingSource1.Filter = "(Convert(ID, 'System.String') LIKE '" & txtCustomer.Text & "')" &
            "OR (Names(s) LIKE '" & txtCustomer.Text & "') OR (OrderID LIKE '" & txtCustomer.Text & "')" &
            "OR (Phone Number LIKE '" & txtCustomer.Text & "')"

            If BindingSource1.Count <> 0 Then
                With dgvOrders
                    .DataSource = BindingSource1
                End With

            Else
                MsgBox("The search item was not found")
                BindingSource1.Filter = Nothing
            End If

        End If
    End Sub
    Private Sub NotFound()
    End Sub

    Private Sub btnMenu_Click(sender As Object, e As EventArgs) Handles btnMenu.Click
        Me.Hide()
        frmMenu.Show()
    End Sub

    Private Sub btnReports_Click(sender As Object, e As EventArgs) Handles btnReports.Click
        Me.Hide()
        frmReport.Show()
    End Sub

    Private Sub btnQuery_Click(sender As Object, e As EventArgs) Handles btnQuery.Click
        Me.Hide()
        frmQuery.Show()
    End Sub

    Private Sub btnStaff_Click(sender As Object, e As EventArgs) Handles btnStaff.Click
        Me.Hide()
        frmStaff.Show()
    End Sub
End Class